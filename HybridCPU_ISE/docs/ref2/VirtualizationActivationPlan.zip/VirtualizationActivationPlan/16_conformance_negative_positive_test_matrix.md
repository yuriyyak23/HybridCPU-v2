# Phase 16 - Conformance Negative Positive Test Matrix

Status: conformance plan. Positive tests are future-gated behind owner-specific RFC/ADR.

## 2026-06-11 Audit Contract

- File name: `16_conformance_negative_positive_test_matrix.md`.
- Purpose: define negative guards required now and future positive tests allowed only after owner-specific RFC/ADR.
- Status: conformance plan; positive tests are `future-gated`.
- Scope: VMCS/store/pointer absence, VmxCaps non-authority, VMREAD/VMWRITE denials, VMCALL missing owner, publication/retire separation, nested/SecureCompute/lane/compiler/migration guards.
- No-goals: no runtime authority from tests, goldens, snapshots, or green suites; no positive tests without RFC/ADR owner map.
- Code anchors: `HybridCPU_ISE.Tests/VmxRefactoring/**`, `HybridCPU_ISE.Tests/SecureComputeRefactoring/**`, `HybridCPU_ISE.Tests/CompilerTests/**`, `CompilerSourceScanner.cs`, `VirtualizationActivationPlanAuditGuardTests.cs`, runtime anchors from Phases 01-15.
- Authority owner: conformance detects and blocks; neutral runtime owners grant authority only after implementation.
- Required RFC/ADR: every positive test must cite accepted RFC/ADR with full owner map: field/operation, owner, value source, capability policy, evidence class, migration class, denial reason.
- Acceptance criteria: negative matrix is runnable now; positive matrix remains disabled/not merged until owner implementation exists; proof-only/admitted-denied are not backend success.
- Tests/static scans: required test groups and scans listed below, plus plan-doc audit metadata guards.
- Risks: broad green test suite being cited as activation proof, or positive tests landing without adjacent denials.
- Next-gate dependency: Phase 17 rollout sequencing and Phase 18 release gate.

## Phase Goal

Define the negative tests that must exist before any activation work and the positive tests that may be enabled only after a complete owner-specific RFC/ADR.

## Current Baseline

Existing VMX refactoring tests cover many denial and projection boundaries, including VMREAD slices, VMCALL admitted-denied path, hypercall backend admission denial, trap route/fence denial, SecureCompute VMX boundary, compiler no-emission, migration/evidence, and closure documentation.

The current positive VMREAD surface includes only field-specific guarded `GuestCr0`/`GuestCr4` read-only projection. Its tests must prove owner/source/visibility/migration/conformance gates and simultaneously prove no mutation, backend success, completion publication, or retire publication.

The phrase "positive VMREAD surface" means a positive direct projection fixture only. It does not mean an architectural VMREAD instruction, dispatcher success, destination-register writeback, completion publication, or retire publication.

Current tests must also validate the evidence manifest and enforce the Phase 17 E0-E7/D2/O1 dependency model plus separate compiler/release gates. A guard that merely finds expected prose is claim hygiene, not runtime conformance.

## 2026-08-06 Verification Snapshot

- Focused plan/projection/backend-denial/route-retire set: `82/82` passed on `net10.0` with .NET SDK `10.0.204`.
- Entire `HybridCPU_ISE.Tests.VmxRefactoring` namespace: `137/137` passed.
- Broad `FullyQualifiedName~Vmx&FullyQualifiedName!~NonVmx` diagnostic run: `474` passed and `1` failed. The failure is `SecureComputePhase22LimitedReleaseGateTests.Docs_RecordFailClosedReleaseGateAndPhase18CompilerVmxBoundaries`, caused by a pre-existing missing phrase in the separately modified SecureCompute activation document; it is outside the files changed by this virtualization-plan audit and is not hidden as a green result.
- Evidence-manifest anchor hashes: verified.
- `git diff --check` for changed plan/WhiteBook/internal-doc/guard files: passed; only existing line-ending conversion warnings were reported.

These results prove only the tested denial/projection/document contracts in the dirty worktree. They are not clean-checkout CI, positive canonical execution, activation, completion or retire evidence.

## 2026-08-07 VRT Reconciliation Verification

- `VirtualizationActivationPlanAuditGuardTests`: `43/43` passed.
- Entire `HybridCPU_ISE.Tests.VmxRefactoring` namespace: `151/151` passed after reconciling archived-plan readers with the user-owned `docs/ref2/Old/VirtualiztionRefactoringNew` location.
- Production scans returned zero matches for the VRT candidate owner/probe/illustrative number, `BackendExecutionAuthorized: true`, `HypercallBackendAdmissionDecision.Allowed`, positive VMX frontend route/completion construction, direct compatibility service calls from execution/pipeline, and compatibility completion factories from execution/pipeline/runtime.
- Generated VMX projection lineage verification passed during build; evidence JSON parses successfully; `git diff --check` reported no whitespace errors (line-ending warnings only).

This verification is current-worktree evidence only. It does not create a clean containing SHA for E1, accept D2, issue an operation-specific E2 certificate, execute a backend, publish completion/retire or approve release.

## ISE-CONFORMANCE-GATES-16 - Closure Record

Closure date: 2026-06-18.

State: closed `READINESS-ONLY / NEGATIVE-MATRIX-CLOSED / POSITIVE-FIXTURES-FUTURE-GATED`.

This closure records the current conformance matrix only. It does not accept an owner RFC/ADR, does not enable positive backend execution tests, does not convert a green suite, generated parity fixture, golden artifact, static scan, or positive-looking fixture into activation proof, and does not open backend execution, completion publication, retire publication, mutation, migration payload authority, SecureCompute activation, lane/stream passthrough, nested execution, or compiler emission.

| Conformance surface | Current result | Authority owner | Evidence class | Migration/evidence requirement | Boundary |
| --- | --- | --- | --- | --- | --- |
| negative VMX/frontend scans | runnable now | none; conformance detects only | static denial evidence | not migration authority | must keep `MissingNeutralOwner`, `ProjectionOnlyDenied`, no `Allowed`, no `BackendExecutionAuthorized: true`, no frontend runtime publication |
| guarded `GuestCr0`/`GuestCr4` positive projection tests | current positive surface only | privileged execution-state owner | read-only projection evidence | `RevalidatedAfterRestore` plus conformance proof | field-local projection only; no mutation, backend, completion, retire, or widening |
| hypercall positive-looking fixtures | future-gated | neutral hypercall backend owner after accepted RFC/ADR | readiness or proof-only evidence | exact migration class required | exact numeric leaf remains unresolved; no VMCALL backend success test may merge without accepted owner map |
| SecureCompute proof/conformance fixtures | denial/proof-only | SecureCompute runtime owners | proof-only or denial evidence | secure migration/evidence policy required | `AllowedSecureOperation` and `AllowedProofOnlyNoExecution` are not backend execution or publication |
| generated parity and golden artifacts | conformance evidence only | generated-schema/runtime owners when separately accepted | parity/golden evidence | not payload authority | generated or golden evidence is not runtime authority and cannot substitute owner acceptance |
| compiler no-emission tests | denied/future-gated | compiler RFC plus accepted runtime owner | no-emission evidence | not migration authority | no VMX/SecureCompute/lane emission authority |
| migration/evidence tests | denied/future-gated | neutral migration/checkpoint owner | payload-denial evidence | explicit class required | VMCS projection metadata, compiler artifacts, proof-only, lane/stream evidence, and VMREAD output remain non-authority |
| future positive tests | not merged/not enabled by this phase | owner-specific RFC/ADR only | implementation evidence after owner acceptance | exact migration/evidence class per path | must separately assert backend execution, completion route, completion fence, retire rule, and adjacent denials |

Closure invariants:

- Conformance tests, fixtures, generated parity, static scans, and goldens are evidence about boundaries; they are not authority.
- A broad green suite is not activation approval and cannot satisfy owner acceptance.
- Positive-looking tests or fixture names are not exact leaf IDs, owner maps, backend execution authorization, completion publication, or retire publication.
- The only current positive projection remains guarded `GuestCr0`/`GuestCr4` read-only projection, with no widening.
- Every future positive test must cite an accepted owner-specific RFC/ADR with exact operation, owner, value source, capability policy, evidence class, migration class, completion policy, retire policy, denial reasons, and adjacent negative tests.
- Proof-only, admitted-denied, manifest-only, visibility-only, no-emission, and readiness-only results must remain non-execution semantics in tests and documentation.

## Owner Of Authority

Conformance proves boundaries. It does not grant authority. Runtime authority remains with neutral owners.

## What Can Be Implemented

Negative tests immediately:

- VMCS store absent.
- Active VMCS pointer absent.
- `VmxCaps` cannot grant authority.
- VMREAD denied fields remain denied.
- `GuestCr0`/`GuestCr4` deny on missing owner/source/visibility/migration/conformance facts and allow only field-specific read-only projection after all gates.
- VMWRITE denied for all fields.
- VMCALL missing neutral owner remains denied.
- `RuntimeOwnedPublication` cannot be used by VMX frontend before backend owner.
- Completion cannot publish without fence.
- Retire cannot publish without explicit retire permission.
- Shadow VMCS cannot own nested state.
- SecureCompute cannot be activated through VMX/VMCS/`VmxCaps`.
- `AllowedSecureOperation` remains admission-only and `AllowedProofOnlyNoExecution` remains proof-only with backend execution false.
- exact VMCALL leaf remains unresolved; candidate class wording cannot enable a positive backend test.
- VRT candidate owner/name/illustrative numeric leaf cannot appear in production code, generated runtime registry or positive fixture before D2 acceptance.
- E1 certificate remains generic fault-only; absent/draft/withdrawn D2, register selector substituted for runtime leaf value, adjacent leaf, operand mutation, revoked capability and stale restore generation must deny E2 issuance/validation.
- a D2 manifest, accepted-looking enum or public boolean cannot be consumed as a runtime authorization token.
- E3 backend receipt, E5 completion token and E6 retire grant must be opaque, owner/attempt-bound and mutually non-substitutable before any future positive test can merge.
- Lane6/Lane7 tokens cannot migrate as guest state.
- Tests/golden artifacts cannot be runtime authority.

Future positive tests:

- neutral owner admits exact operation;
- capability and evidence policy required;
- backend execution authorized only by owner;
- completion route authorized only after backend success;
- fence creates completion only when route permits;
- retire policy permits only exact approved path;
- migration class explicit;
- adjacent denied states remain denied;
- rollback and host-evidence non-leak pass.

## What Remains Denied/Future-Gated

All positive tests remain disabled/not merged unless their owner-specific RFC/ADR is accepted and the implementation exists.

## Forbidden Shortcuts

- Skipping negative tests because the positive path is narrow.
- Treating broad green test suite as activation proof.
- Using snapshots/goldens as owner evidence.
- Enabling positive tests before owner map is complete.

## Required RFC/ADR

Negative tests require no RFC/ADR. Every positive test must cite a specific RFC/ADR ID and owner map.

## Code Anchors

- `HybridCPU_ISE.Tests/VmxRefactoring/**`
- `HybridCPU_ISE.Tests/SecureComputeRefactoring/**`
- `HybridCPU_ISE.Tests/CompilerTests/**`
- `HybridCPU_ISE.Tests/TestHelpers/CompilerSourceScanner.cs`
- `HybridCPU_ISE.Tests/VmxRefactoring/VirtualizationActivationPlanAuditGuardTests.cs`
- Runtime and virtualization anchors from Phases 01-15.

## Documentation Anchors

- `HybridCPU_ISE/docs/ref2/Old/VirtualiztionRefactoringNew/13_conformance_golden_artifacts_and_static_gates.md`
- `Documentation/Virtualization WhiteBook/14_Conformance_Golden_Artifacts.md`
- `Documentation/Virtualization WhiteBook/19_Source_References_And_Check_Commands.md`
- `Documentation/SecureCompute WhiteBook/SecureCompute HybridCPU-v2 WhiteBook.md`

## Required Tests

Suggested new test groups:

- `VirtualizationActivationPlanBaselineTests`
- `VirtualizationActivationPlanAuditGuardTests`
- `VmxRuntimeOwnedPublicationMisuseStaticTests`
- `VmxNoVmcsAuthorityRegressionTests`
- `VmxSecureComputeAuthorityAbsenceTests`
- `VmxLaneStreamEvidenceNonAuthorityTests`
- `VmxHypercallOwnerPositivePathTests` only after Phase 06/07 implementation.
- `GuestCr0Cr4ReadOnlyProjectionTests`
- `PrivilegedExecutionStateOwnerPolicyTests`
- `SecureBackendOwnerRfcGateTests`
- `SecureComputeDomainDescriptorNoEffectTests`

## Required Static/Source Scans

```powershell
rg -n "VmcsManager|IVmcsManager|VmxExecutionUnit|ActiveVmcs|VmcsFieldStore" HybridCPU_ISE --glob "*.cs"
rg -n "RuntimeOwnedPublication" HybridCPU_ISE/CloseToHSL/Core/Virtualization HybridCPU_ISE/CloseToHSL/Core/Runtime
rg -n "VmxCaps.*grant|VMCS.*authority|SecureCompute.*VMX|Lane6|Lane7|Stream.*authority" HybridCPU_ISE Documentation
rg -n "AllowedSecureOperation|AllowedProofOnlyNoExecution|BackendExecutionAuthorized:\s*true" HybridCPU_ISE/CloseToHSL/Core/Runtime/Domains/SecureCompute HybridCPU_ISE/CloseToHSL/Core/Virtualization
rg -n "HCPU_HV_PROBE_V1|0x48594350_00000001|DomainHypercallRuntimeOwner" HybridCPU_ISE/CloseToHSL --glob "*.cs"
rg -n "FromCompatibilityExit\(|TryFromCompatibilityExit\(" HybridCPU_ISE/CloseToHSL/Core/Execution HybridCPU_ISE/CloseToHSL/Core/Pipeline HybridCPU_ISE/CloseToHSL/Core/Runtime
rg -n "<release-policy-overclaim-denylist>" HybridCPU_ISE/docs Documentation
```

## Migration/Evidence Classification

Every positive test must assert migration/evidence class. Every negative test must assert that host-owned evidence, debug traces, scheduler evidence, native tokens, backend handles, VMCS projection metadata, and tests/goldens are not runtime authority. Every plan-doc guard test in this directory must assert that proof-only and admitted-denied semantics do not become backend success wording.

## Completion/Retire Implications

Positive tests must separately assert backend execution, completion route, completion fence, and retire rule. A single success assertion is insufficient.

## Exit Criteria

- Negative matrix is implementable immediately.
- Positive matrix is clearly gated by RFC/ADR.
- Static scans have expected outcomes and allowlist discipline.

## Dependency On Previous/Next Phase

Depends on all previous phases. Phase 17 orders the PRs; Phase 18 defines release gate.

## 2026-08-07 D2/E2 Negative Gate Addition

`VmxD2DecisionAndE2NegativeSubstrateTests` now denies non-accepted decisions, missing/mismatched attribution, absent CODEOWNERS proof, compatibility self-approval and absent exact-leaf cardinality. It also proves that the disabled owner interface has no execution method, the E2 certificate has no public constructor or issuer, schema data contains no appointed owner/operation/leaf, the VMX frontend still supplies `MissingNeutralOwner` and `ProjectionOnlyDenied`, and no backend/completion/retire shortcut was introduced. These are negative readiness checks only and do not satisfy D2.

Phase 35 additionally denies malformed accepted-commit SHA, required-reviewer mismatch, duplicate leaves and incomplete owner map. It proves the repository-owner review workflow has no approve, accept, appoint or execution API and reports no appointment, decision-acceptance or backend authority. No test fixture supplies a selected or reserved leaf.
