# Phase 19 - Open Decision Backlog

Status: `PASS / ACTIVE STATUS REGISTER`. Phase 38 accepts the exact first-slice architecture/ABI decision; machine D2 and every production runtime stage remain blocked or future-gated until their typed gates are completed.

## 2026-08-06 Compact Status Journal

This is the active journal. Files `20_hv_rfc_intake_packet.md` through `31_hv_post_baseline_artifact_sentry.md` are retained as historical evidence snapshots only; they are not phases, dependencies, authorization, or a reason to keep generating monitor/wait documents.

| Date | Historical records | Checked event | Result | Fail-closed meaning |
| --- | --- | --- | --- | --- |
| 2026-06-18 | 20-24 | draft intake, handoff, no-response and late-response audit | no attributable neutral owner acceptance/rejection/amendment; no exact numeric leaf | draft/handoff/silence do not grant authority; VMCALL remains denied |
| 2026-06-18 | 25-27 | monitor, artifact recheck, wait-or-reselect checkpoint | no owner artifact; wait retained; no replacement selected | time, monitor closure and candidate availability do not grant authority |
| 2026-06-18 | 28-30 | denied-chain refresh, watchdog, final wait baseline | `MissingNeutralOwner -> backend denied -> ProjectionOnlyDenied -> completion denied -> retire denied` preserved | closed checks prove denial only; no implementation permission |
| 2026-06-19 | 31 | post-baseline sentry | no attributable artifact and no replacement | wait history closed; future checks append one row here only when external state changes |
| 2026-08-06 | current HEAD/worktree recheck | code, callers, tests, Git provenance and external-audit claims | no accepted owner, no exact leaf, no backend, no canonical backend composition, no completion publication and no successful VMX retire | active state beyond fault-only E1 remains `BLOCKED / DENIED / FUTURE-GATED / NO-GO` |
| 2026-08-06 | clean local subject `b6d4871...` and E1 readiness refresh | clean Git subject, tracked source layout, source hashes, local VMX CI, non-forgeability contract and static absence guards | E0 clean-subject provenance closed; E1 contract/static gate closed but certificate implementation absent | provenance is evidence only; E2-E7 stay blocked, compiler and release gates remain unopened, and no activation/backend/completion/retire authority is created |
| 2026-08-06 | E1 production implementation | SafetyVerifier issuer/live registry, source/working-slot and bundle/replay binding, canonical issue-packet lane-7 transport, mutation/invalidation/foreign-issuer denials and fault-only execution/retire | E1 closed `FAULT-ONLY`; compatibility booleans remain non-authoritative and certificate flags for backend/completion/retire remain false | E2-E7 stay blocked; compiler and release gates remain unopened; this is typed admission transport, not execution or activation |
| 2026-08-07 | VRT reports at remote SHA `d3814d1...` reconciled in Phase 33 | current callers, operand capture, WhiteBook authority, governance manual, CI/generator and Git state rechecked locally | core fail-closed findings confirmed; neutral means external-to-compatibility-plane; D2/E2/E3 split adopted; candidate owner/name/number not accepted | next pool is clean-SHA refresh plus D2 schema/validation and denied E2 substrate only; backend/completion/retire remain prohibited |
| 2026-08-08 | `deep-research-report 2.md` reconciled against local `ddfffa2...` plus worktree | decode/payload types, canonical P2 seam, D2 validator, completion factories, retire factories, callers and WhiteBook rechecked | selector/value gap, D2 provenance circularity risk and E3/E5/E6 authority gaps confirmed; P2 is already closed; 16-bit width is only a candidate, not an accepted ABI | no P3; next safe pool is D2 v2 governance hardening and negative/static checks only |
| 2026-08-09 | `HybridCPU-v2 Virtualization Activation 3.md` verified and accepted through Phase 38 repository-owner ADR | namespace collision, VMCALL operand model, x0/no-result shape, neutral owner boundaries, v1 D2/E2 substrate, completion/retire and WhiteBook checked | role `DomainHypercallRuntimeOwner` and exact `HybridCPU.VMCALL.Runtime.v1` / 16-bit / `0x0001` / `PROBE_NO_STATE_V1` / no-state/no-payload / `DrainOnly` architecture accepted with O1/operand correction | machine D2 remains blocked on SpecV2, AcceptanceRecordV2, non-zero OwnerId, attributable reviewers/CODEOWNERS and accepted instance; production stays fault-only |
| 2026-08-09 | external normative-edit audit rechecked locally | Phase 38 runtime/readiness graphs, current fence construction, completion migration enum, domain operation kinds, Phase 07 identity rule, WhiteBook Lane 6/7 ownership and local/public provenance boundary | corrections confirmed and incorporated in Phases 06/07/08/12/17/18/19/38; E4 is composition proof, E5 is atomic publication proof, and staged transactions preserve existing owners | exact machine D2 policies remain owner-unresolved; first-slice SecureCompute is denied; production stays fault-only |

Journal rule: unchanged external state does not create another phase or permission. A new row is allowed only for a materially new attributable owner artifact, a changed exact decision, a provenance change, or a changed production call graph. Every row defaults to denied until its evidence is independently verified.

Historical compact trace retained for stable verification: Phase 07 denied baseline frozen `BLOCKED-BASELINE / NO-ACTIVATION`; Phase 20 prepared owner-facing packet; Phase 21 recorded handoff and found no attributable owner response; Phase 22 fallback is wait-or-reselect with VMCALL denied/future-gated; Phase 23 selected wait/no replacement; Phase 24 late audit found no attributable owner response; Phase 25 monitor-only cadence found no attributable owner response; Phase 26 artifact-triggered recheck found no attributable owner artifact and did not fire the gate; Phase 27 wait-or-reselect checkpoint continues wait and selects no replacement; Phase 28 denied-chain refresh preserves `MissingNeutralOwner` -> backend denied -> `ProjectionOnlyDenied` -> completion/retire denied; Phase 29 watchdog found no attributable owner response and preserved the denied chain; Phase 30 final wait-baseline closes the current wait series with no owner artifact, no exact leaf, no replacement, and denied chain preserved; Phase 31 post-baseline sentry found no owner artifact and no replacement selection. These are historical facts only and are superseded for the current architecture decision by Phase 38; they still prove that wait/monitor history granted no runtime authority.

P1 and P2 are closed TESTING-only evidence. P1 and P2 are closed as TESTING-only evidence. Neither satisfies machine D2/O1/E2/E3/E4, and no P3 is authorized.

Current decision keys:

- `E0-PROVENANCE`: closed/evidence-only for clean local subject `b6d4871e0f06ebde07015e393c0d36af0362f506`; canonical `CloseToHSL` is tracked and obsolete `CloseToRTL` has zero tracked files.
- `E1-TYPED-ADMISSION`: closed/fault-only; production certificate, SafetyVerifier-exclusive live issuance/validation and canonical issue-packet lane-7 transport are implemented; caller-supplied booleans remain non-authoritative and backend/completion/retire flags are false.
- `D2-VMCALL-OWNER`: architecture role `DomainHypercallRuntimeOwner` accepted by Phase 38; machine/runtime materialization remains blocked because stable non-zero OwnerId, reviewer/CODEOWNERS attribution, accepted v2 artifact and runtime service are absent.
- `D2-VMCALL-LEAF`: architecture ABI accepted only in namespace `HybridCPU.VMCALL.Runtime.v1`: width 16, invalid `0x0000`, leaf `0x0001`, operation `PROBE_NO_STATE_V1`. It is not yet a generated registry entry or runtime capability.
- `D2-ACCEPTANCE-PROVENANCE`: blocked; the current v1 manifest places `AcceptedCommitSha` in the same object that declares `Accepted`, so it is retained only as fail-closed substrate. The v2 gate must separate immutable `VirtualizationDecisionSpecV2` from later `VirtualizationDecisionAcceptanceRecordV2` referencing the specification SHA and digest.
- `D2-VMCALL-WIDTH`: decided as 16-bit by Phase 38, with full-register upper bits required to be zero and silent truncation denied. Compatibility `ushort` types remain constraints/evidence only, not authority.
- `O1-OWNER-POLICY`: blocked on machine D2; O1 now means immutable `VirtualizationOperationOwnerSnapshot`, not the operand snapshot.
- `E2-VMCALL-ADMISSION`: blocked on D2; E1 remains generic fault-only and does not bind a runtime numeric leaf value.
- `E2-OPERAND-SNAPSHOT`: blocked on machine D2/O1; current decode preserves `rs1`/`rs2` selectors, not their runtime values. Production E2 requires a separate immutable canonical operand snapshot tied to the admitted attempt; neither backend nor retire may re-read the register file.
- `E3-E7`: future-gated by the preceding dependency model in Phase 17; compiler and release gates remain unopened.
- `GUEST-CR0-CR4`: closed only as guarded direct read-only projection; no widening and no architectural VMREAD claim.

## 2026-06-11 Audit Contract

- File name: `19_open_decision_backlog.md`.
- Purpose: keep unresolved decisions explicit so they do not become implementation assumptions.
- Status: architecture decision for the exact first VMCALL slice is accepted in Phase 38; machine D2 and runtime stages remain denied, blocked or `future-gated`.
- Scope: minimal VMCALL owner, CR0/CR4, host aliases, controls, VMWRITE, nested, SecureCompute visibility/backend, lane/stream passthrough, compiler emission, migration payloads, release wording.
- No-goals: no backlog entry as approval, no bundled broad activation PR, no implicit migration/evidence class.
- Code anchors: path-specific anchors from Phases 04-15.
- Authority owner: each promoted item must name its neutral owner; backlog text is not authority.
- Required RFC/ADR: required for every promoted item with full owner map: field/operation, owner, value source, capability policy, evidence class, migration class, denial reason.
- Acceptance criteria: unpromoted items are `не доказано`, `future-gated`, `должно оставаться denied`, and `требует owner-specific RFC/ADR`.
- Tests/static scans: each backlog item keeps denied-state tests until promoted; promotion requires positive and negative tests plus Phase 16 scans.
- Risks: using backlog priority as implementation permission or widening the first VMCALL owner to unrelated surfaces.
- Next-gate dependency: one named owner-specific RFC/ADR for the next production work.

## Phase Goal

Record unresolved decisions so they do not silently become implementation assumptions.

## Current Baseline

No production activation path is approved. Phase 38 is the accepted repository-owner architecture/ABI ADR for the minimal VMCALL slice; machine D2 and every runtime authority stage remain incomplete.

## ISE-BACKLOG-RFC-INTAKE-19 - Closure Record

Closure date: 2026-06-18.

State: closed `INTAKE-SELECTED / OWNER-ACCEPTANCE-REQUIRED / DENIED-FUTURE-GATED`.

Selected next owner-specific RFC/ADR intake: `Minimal VMCALL backend owner`.

This selection chooses the next intake queue item only. It does not accept an RFC/ADR, allocate an exact numeric VMCALL leaf, approve `HypercallBackendAdmissionDecision.Allowed`, authorize backend execution, publish completion, publish retire, mutate VMCS state, widen `GuestCr0`/`GuestCr4`, or grant migration, SecureCompute, compiler, lane/stream, nested, I/O, IOMMU, host-alias, compatibility-control, release, or implementation authority.

Intake decision matrix:

| Intake candidate | Selection result | Required external owner artifact | Still denied/future-gated |
| --- | --- | --- | --- |
| Minimal VMCALL backend owner | selected as next RFC/ADR intake | attributable neutral-runtime-owner acceptance or rejection with exact numeric leaf, argument ABI, value/result source, capability policy, evidence class, migration class, completion rule, retire rule, and adjacent denials | all runtime behavior until accepted |
| `GuestCr0`/`GuestCr4` projection widening | not selected | separate owner-specific RFC/ADR for any field beyond guarded read-only projection | mutation/backend/completion/retire/widening |
| VMWRITE | not selected | neutral write owner per state class | all writes |
| Nested child intent | not selected | neutral child-intent owner RFC/ADR | VMCS12/VMCS02/Shadow VMCS authority and nested execution |
| SecureCompute VMX visibility/backend | not selected | secure runtime owner RFC/ADR plus virtualization boundary proof | SecureCompute activation through VMX/VMCS/`VmxCaps` |
| Lane6/Lane7/Stream passthrough | not selected | memory/I/O/lane owner RFC/ADR with evidence non-leak | passthrough and payload authority |
| Compiler controlled emission | not selected | compiler emission RFC tied to accepted runtime owner RFC/ADR | VMX/SecureCompute/lane/stream emission |
| Migration payloads for active path | not selected as standalone activation | neutral migration descriptor only after an accepted active path exists | checkpoint/restore payload authority |
| Release claim wording | not selected as implementation input | Phase 18 release review only after exact implementation chain exists | broad release claim |

Selected intake invariants:

- Intake selection is not owner acceptance.
- Backlog priority is not implementation permission.
- Exact leaf class, opcode, exit reason, owner ID, register selector, SecureCompute fixture value, or VMFUNC leaf is not an exact numeric VMCALL leaf.
- Draft, silence, handoff, no-response audit, blocked baseline, closed conformance gate, rollout order, release gate, or this closure record is not acceptance.
- Until an attributable accepted neutral-runtime-owner artifact independent from the compatibility authority plane exists, Phase 06B/Phase 07 production work remains blocked/future-gated. That owner may be repository-local; this plan does not appoint it.
- Positive-looking readiness evidence cannot replace the full owner map or convert admitted-denied/proof-only semantics into execution.

## Confirmed Closures From Current Audit

Historical statements using "external neutral owner", "no selected leaf", or "candidate DomainHypercallRuntimeOwner" are preserved as historical observations only. They MUST NOT be consumed as current decision state. Current decision state is defined only by the 2026-08-09 All-Phase Blocker Register, Adopted Resolution Of Phase 19 Blockers, and Phase 38.

The following audit items are already confirmed in code, docs, or tests and are no longer treated as open backlog assumptions:

- `ISE-VMX-GUARD-01`: closed. Current tests and scans keep `MissingNeutralOwner` in the VMX frontend, with no `HypercallBackendDecision.Allowed`, no `BackendExecutionAuthorized: true`, and no `RuntimeOwnedPublication` in VMX frontend code.
- `ISE-VMX-GUARD-03`: closed. VMX frontend remains `ProjectionOnlyDenied` and does not construct completion or retire publication.
- `ISE-HV-RFC-01`: closed as a draft-only denied skeleton. `NeutralHypercallBackendOwnerDescriptor` exists, but it stays draft-only and does not open backend execution.
- `ISE-HV-OWNERMAP-02`: closed at the docs level. The candidate leaf owner map is recorded in Phase 06/07 docs with field/operation, owner, value source, capability policy, evidence class, migration class, and denial reason.
- `ISE-HV-ADMISSION-03`: closed. There is still no `HypercallBackendAdmissionDecision.Allowed`, and no code path sets `BackendExecutionAuthorized: true`.
- `ISE-HV-LEAF-DECISION-04`: decision-ready but not accepted. The verified ABI inventory proves `VMCALL=259` only as an opcode, proves the `rs1`/`rs2` register-selector operand form, rejects VMFUNC leaves `1/7/8`, exit reason `18`, owner ID `0x060A`, register selector `2`, and SecureCompute test fixture `0x10` as VMCALL leaf authority, and records that the exact numeric VMCALL leaf remains `не доказано`, `future-gated`, and `требует owner-specific RFC/ADR`.
- `ISE-HV-RFC-OWNER-DECISION-05`: closed `NO-GO` on 2026-06-12. No accepted neutral-runtime-owner RFC/ADR or exact VMCALL leaf was found. The closure is process/audit evidence only and does not accept or reject the RFC on behalf of neutral runtime owners; Phase 06B/07 remain blocked.
- `ISE-HV-OWNER-ACCEPTANCE-HANDOFF-06`: closed `NO-DECISION / RETURNED-BLOCKED` on 2026-06-12. No attributable external neutral-runtime-owner acceptance or rejection artifact was found. The handoff is complete, but its implementation dependency remains unresolved; it grants no Phase 06B or Phase 07 permission.
- `ISE-HV-OWNER-RESPONSE-07`: closed `NO-RESPONSE / EXTERNAL-BLOCKED` on 2026-06-12. The post-handoff response audit found no acceptance, rejection, amendment, exact-leaf allocation, or owner-signed replacement RFC/ADR. Audit completion is not owner acceptance; Phase 06B/07 remain blocked.
- `ISE-HV-PHASE07-BLOCKED-BASELINE-08`: closed `BLOCKED-BASELINE / NO-ACTIVATION` on 2026-06-12. The denied production chain is frozen at `MissingNeutralOwner` -> backend unauthorized -> `ProjectionOnlyDenied` -> completion/retire denied. This closes only the baseline audit and grants no Phase 07 implementation or Phase 08 consumption.
- `ISE-COMP-ROUTE-01`: closed as future-gated route scaffolding. `RuntimeOwnedCompletionPublication` separates the completion route flag from retire, remains absent from VMX frontend, and does not publish a completion record.
- `ISE-COMP-FENCE-02`: closed as future-gated neutral fence scaffolding. `CompletionPublishedRetireDenied` permits a neutral completion record while retire remains false; host-owned evidence and missing/unsafe migration classification cannot grant retire. VMX frontend remains on the admitted-denied path.
- `ISE-HV-RETIRE-PUBLICATION-GATE-09`: closed `FUTURE-GATED RETIRE GATE / COMPLETION-NOT-RETIRE / NO-RETIRE-PUBLICATION / NO-PRODUCTION-CHANGE` on 2026-06-18. Retire publication remains a separate future-gated owner rule; completion-only scaffolding, `CompletionPublishedRetireDenied`, `VmExitReason`, completion kind, route descriptor flags, fence shape, green tests, scans, or release wording grant no backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, release claim, or implementation permission.
- `ISE-VMREAD-PES-01`: closed as guarded read-only projection. A neutral privileged execution-state descriptor, owner policy, and separate projection service can expose only `GuestCr0`/`GuestCr4` after owner/source/visibility/`RevalidatedAfterRestore`/conformance gates; mutation, backend execution, completion, retire, host aliases, unsupported fields, and writes remain denied.
- `ISE-VMREAD-DENIED-SURFACES-09`: closed `DENIED-BASELINE / NO-PROJECTION-WIDENING` on 2026-06-18. Host execution aliases, `HostCr3`, compatibility-control VMREAD values, unknown fields, and writes remain denied because their neutral owners/value contracts are absent.
- `ISE-VMWRITE-DENY-BASELINE-10`: closed `DENIED-BASELINE / NO-WRITE-OWNER` on 2026-06-18. Generated schema writes, compatibility-control writes, VMWRITE scalar stores, and SecureCompute-sensitive VMWRITE remain denied; opcode/decode vocabulary is not mutation authority.
- `ISE-NESTED-CHILD-INTENT-BASELINE-11`: closed `DENIED/FUTURE-GATED BASELINE / NO-NESTED-ACTIVATION` on 2026-06-18. Child intent remains read-only compatibility projection, Shadow VMCS fails closed, VMCS12/VMCS02 payload authority is denied, and production VMX paths do not call nested enablement.
- `ISE-MEM-IO-LANE-STREAM-BOUNDARY-12`: closed `DENIED/FUTURE-GATED BASELINE / NO-PASSTHROUGH-AUTHORITY` on 2026-06-18. Memory-owned VMREAD remains projection-only; I/O/IOMMU aliases fail closed; Lane6/Lane7/Stream helper, telemetry, token, replay, and backend-binding surfaces remain non-authoritative for VMX/SecureCompute/publication/migration.
- `ISE-SECCOMP-VMX-BOUNDARY-13`: closed `DENIED/PROOF-ONLY BASELINE / NO-SECCOMP-VMX-ACTIVATION` on 2026-06-18. SecureCompute remains owned by secure runtime descriptors and policies; `AllowedSecureOperation` is admission-only, `AllowedProofOnlyNoExecution` is proof-only/no-execution, VMX/VMCS/Shadow VMCS/`VmxCaps` are non-authority sources, and no secure backend execution, completion publication, retire publication, or migration authority is opened.
- `ISE-COMPILER-NOEMISSION-GATE-14`: closed `DENIED/FUTURE-GATED BASELINE / NO-COMPILER-EMISSION-AUTHORITY` on 2026-06-18. Compiler VMX metadata remains diagnostic/raw transport vocabulary, VMCS sidebands remain validation-only, no-emission and lowering gates deny direct substrate/handler/native-lane emission, SecureCompute controlled emission keeps `CompilerEmissionAuthorized: false`, and no VMX/SecureCompute/lane/stream backend, completion, retire, or migration authority is opened.
- `ISE-MIGRATION-PAYLOAD-AUTHORITY-15`: closed `DENIED/FUTURE-GATED BASELINE / NO-MIGRATION-PAYLOAD-AUTHORITY` on 2026-06-18. VMCS/compatibility projection metadata, compiler artifacts, SecureCompute proof-only admissions, lane/stream tokens, telemetry, replay evidence, backend bindings, debug traces, and completion projections remain non-authoritative for checkpoint/restore; `GuestCr0`/`GuestCr4` remain `RevalidatedAfterRestore`.
- `ISE-CONFORMANCE-GATES-16`: closed `READINESS-ONLY / NEGATIVE-MATRIX-CLOSED / POSITIVE-FIXTURES-FUTURE-GATED` on 2026-06-18. Conformance tests, generated parity, static scans, goldens, and positive-looking fixtures remain boundary/readiness evidence only; they grant no owner acceptance, exact leaf, backend execution, completion publication, retire publication, mutation, migration payload authority, SecureCompute activation, lane/stream passthrough, nested execution, or compiler emission.
- `ISE-ROLLOUT-ORDER-GATE-17`: closed `SEQUENCING-ONLY / READINESS-ONLY / NO-IMPLEMENTATION-PERMISSION` on 2026-06-18. Rollout order, PR sequencing, closed audits, handoffs, response checks, conformance gates, and backlog rows remain process/readiness evidence only; they grant no owner acceptance, exact leaf, backend execution, completion publication, retire publication, mutation, migration payload authority, SecureCompute activation, lane/stream passthrough, nested execution, compiler emission, or release claim.
- `ISE-RELEASE-GATE-18`: closed `READINESS/FINAL-CLAIM GATE / NO-BROAD-RELEASE-CLAIM / NO-IMPLEMENTATION-PERMISSION` on 2026-06-18. Release review, release notes, final-claim wording, closed audits, green tests/scans/goldens, PR order, rollout sequencing, backlog rows, handoffs, and response audits remain claim-boundary/readiness evidence only; they grant no owner acceptance, exact leaf, backend execution, completion publication, retire publication, mutation, migration payload authority, SecureCompute activation, lane/stream passthrough, nested execution, compiler emission, implementation permission, or broad release claim.
- `ISE-HV-RFC-INTAKE-PACKET-20`: closed `OWNER-FACING PACKET PREPARED / DRAFT-ONLY / OWNER-ACCEPTANCE-REQUIRED / NO-PRODUCTION-CHANGE` on 2026-06-18. The packet for `RFC-HV-VMCALL-NO-STATE-OWNER-0001` is ready for neutral runtime owner accept/reject/amend review, but it grants no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, release claim, or implementation permission.
- `ISE-HV-OWNER-HANDOFF-PACKET-21`: closed `HANDOFF-RECORDED / RESPONSE-AUDITED / NO-RESPONSE / EXTERNAL-BLOCKED` on 2026-06-18. The Phase 20 packet handoff is recorded and response audit found no attributable external neutral-runtime-owner accept/reject/amend artifact; handoff completion and response audit completion grant no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, release claim, or implementation permission.
- `ISE-HV-NO-RESPONSE-ROLLBACK-22`: closed `NO-RESPONSE FALLBACK / WAIT-OR-RESELECT / VMCALL-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-18. Default fallback is to wait for an attributable VMCALL owner response; a future replacement intake may be selected only as a process-only backlog action. No-response fallback, rollback-to-wait, re-audit, replacement discussion, or backlog reprioritization grants no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, release claim, or implementation permission.
- `ISE-HV-REPLACEMENT-INTAKE-DECISION-23`: closed `PROCESS-ONLY WAIT DECISION / NO-REPLACEMENT-SELECTED / VMCALL-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-18. The process decision is to continue waiting for an attributable VMCALL owner response; no replacement intake is selected. Waiting, not selecting a replacement, candidate ranking, clean scans, green tests, or backlog priority grants no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, release claim, or implementation permission.
- `ISE-HV-LATE-OWNER-RESPONSE-AUDIT-24`: closed `LATE-RESPONSE-AUDITED / NO-ATTRIBUTABLE-OWNER-RESPONSE / WAIT-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-18. The periodic audit found no attributable external neutral-runtime-owner accept/reject/amend artifact for `RFC-HV-VMCALL-NO-STATE-OWNER-0001`; audit completion, no-response, clean scans, green tests, and elapsed time grant no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, release claim, or implementation permission.
- `ISE-HV-WAIT-STATE-MONITOR-25`: closed `MONITOR-ONLY-CADENCE / NO-ATTRIBUTABLE-OWNER-RESPONSE / WAIT-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-18. The monitor-only cadence found no attributable external neutral-runtime-owner accept/reject/amend artifact for `RFC-HV-VMCALL-NO-STATE-OWNER-0001`; monitor completion, repeated no-response, backlog age, clean scans, green tests, and elapsed time grant no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, replacement intake selection, release claim, or implementation permission.
- `ISE-HV-OWNER-ARTIFACT-RECHECK-26`: closed `ARTIFACT-RECHECKED / NO-ATTRIBUTABLE-OWNER-ARTIFACT / GATE-NOT-FIRED / WAIT-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-18. The artifact-triggered response audit gate found no attributable external neutral-runtime-owner accept/reject/amend artifact for `RFC-HV-VMCALL-NO-STATE-OWNER-0001`; artifact recheck completion, gate non-fire, repository-local draft text, clean scans, green tests, backlog age, and elapsed time grant no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, replacement intake selection, release claim, or implementation permission.
- `ISE-HV-WAIT-OR-RESELECT-CHECKPOINT-27`: closed `PROCESS-CHECKPOINT / WAIT-CONTINUES / NO-REPLACEMENT-SELECTED / NO-ATTRIBUTABLE-OWNER-ARTIFACT / WAIT-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-18. The process-only checkpoint continues waiting for an attributable external neutral-runtime-owner artifact for `RFC-HV-VMCALL-NO-STATE-OWNER-0001` and selects no replacement intake; checkpoint closure, wait continuation, no-reselect, candidate availability, backlog priority, clean scans, green tests, backlog age, and elapsed time grant no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, replacement intake selection, release claim, or implementation permission.
- `ISE-HV-DENIED-CHAIN-REFRESH-28`: closed `DENIED-CHAIN-REFRESH / MISSING-OWNER-PRESERVED / PROJECTION-ONLY-DENIED / COMPLETION-RETIRE-DENIED / WAIT-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-18. The readiness-only refresh confirmed the current VMCALL production chain remains `MissingNeutralOwner` -> backend denied -> `ProjectionOnlyDenied` -> completion publication denied -> retire publication denied; denied-chain refresh, preserved missing owner, preserved projection-only route, route scaffolding, completion fence scaffolding, clean scans, green tests, closed audits, and current denied behavior grant no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, replacement intake selection, release claim, or implementation permission.
- `ISE-HV-OWNER-RESPONSE-WATCHDOG-29`: closed `WATCHDOG-ONLY / NO-ATTRIBUTABLE-OWNER-RESPONSE / DENIED-CHAIN-PRESERVED / WAIT-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-18. The watchdog-only repeat check found no attributable external neutral-runtime-owner accept/reject/amend artifact for `RFC-HV-VMCALL-NO-STATE-OWNER-0001`; watchdog closure, watchdog tick, watchdog timeout, repeated silence, stable denied behavior, clean scans, green tests, closed audits, and elapsed time grant no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, replacement intake selection, release claim, or implementation permission.
- `ISE-HV-FINAL-WAIT-BASELINE-30`: closed `FINAL-WAIT-BASELINE / NO-ATTRIBUTABLE-OWNER-ARTIFACT / NO-REPLACEMENT-SELECTED / DENIED-CHAIN-PRESERVED / WAIT-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-18. The final wait-baseline snapshot for the current VMCALL owner-response series found no attributable external neutral-runtime-owner accept/reject/amend artifact, no exact numeric VMCALL leaf, and no replacement intake selection; final baseline closure, closed-series wording, stable denied behavior, clean scans, green tests, closed audits, backlog wording, and elapsed time grant no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, replacement intake selection, release claim, or implementation permission.
- `ISE-HV-POST-BASELINE-ARTIFACT-SENTRY-31`: closed `POST-BASELINE-SENTRY / NO-ATTRIBUTABLE-OWNER-ARTIFACT / NO-REPLACEMENT-SELECTED / WAIT-DENIED-FUTURE-GATED / NO-PRODUCTION-CHANGE` on 2026-06-19. The post-baseline sentry-only check found no attributable external neutral-runtime-owner accept/reject/amend artifact for `RFC-HV-VMCALL-NO-STATE-OWNER-0001` and no explicit replacement intake selection; sentry closure, sentry tick, closed-series baseline, stable denied behavior, clean scans, green tests, backlog wording, and elapsed time grant no owner acceptance, exact leaf allocation, backend admission allow, backend execution, completion publication, retire publication, VMX frontend wiring, migration payload authority, SecureCompute activation, lane/stream passthrough, compiler emission, replacement intake selection, release claim, or implementation permission.

## Owner Of Authority

Each backlog item must name a future neutral owner before it can leave the backlog. Neutral means independent from the VMX/VMCS compatibility authority plane, not necessarily external to the repository; attribution and required review still must be machine-verifiable.

## Backlog

| Topic | Current status | Required owner/decision | Default result |
| --- | --- | --- | --- |
| Minimal VMCALL backend owner | historical wait series 20-31 granted no authority; Phase 33 confirmed selector/value and provenance gaps; Phase 38 now accepts the architecture role and exact first-slice ABI, while production still follows `MissingNeutralOwner` -> backend denied -> `ProjectionOnlyDenied` -> completion/retire denied | machine D2: SpecV2 plus later AcceptanceRecordV2, stable non-zero OwnerId, attributable reviewer/CODEOWNERS evidence, exact generated lookup and complete capability/evidence/domain/migration/completion/retire map | future-gated; PR-A may add only v2 governance/negative substrate, then PR-B may materialize attributable machine D2 while backend stays denied |
| `GuestCr0`/`GuestCr4` projection widening | guarded read-only projection implemented | new owner-specific RFC/ADR for any additional field, mutation, backend, completion, retire, or migration behavior | denied outside current field-local projection |
| Host execution aliases | denied baseline closed by `ISE-VMREAD-DENIED-SURFACES-09` | host-execution owner RFC/ADR | denied |
| `HostCr3` | denied baseline closed by `ISE-VMREAD-DENIED-SURFACES-09` | host-address-space owner RFC/ADR | denied |
| Compatibility-control VMREAD values | denied baseline closed by `ISE-VMREAD-DENIED-SURFACES-09` | neutral control-bit value contract | denied |
| VMWRITE | denied baseline closed by `ISE-VMWRITE-DENY-BASELINE-10` | neutral write owner per state class | denied |
| Nested child intent | denied/future-gated baseline closed by `ISE-NESTED-CHILD-INTENT-BASELINE-11`; Shadow VMCS/VMCS12/VMCS02 remain non-authority | neutral child-intent owner RFC/ADR | future-gated |
| SecureCompute VMX visibility | denied/proof-only baseline closed by `ISE-SECCOMP-VMX-BOUNDARY-13`; projection remains guarded read-only and no VMX/VMCS/`VmxCaps` authority exists | secure runtime owner plus visibility/migration/conformance proof | denied by default |
| SecureCompute backend execution | outside this virtualization path; `AllowedSecureOperation` is admission-only and `AllowedProofOnlyNoExecution` is proof-only/no-execution under `ISE-SECCOMP-VMX-BOUNDARY-13` | separate SecureCompute owner RFC/ADR | denied |
| Lane6/Lane7/Stream passthrough | denied/future-gated baseline closed by `ISE-MEM-IO-LANE-STREAM-BOUNDARY-12`; model/helper-only evidence remains non-authority | memory/I/O/lane owner RFC with evidence non-leak | denied |
| Compiler controlled emission | denied/future-gated baseline closed by `ISE-COMPILER-NOEMISSION-GATE-14`; metadata, examples, sidebands, decode, no-emission validation, and lowering readiness are non-authority | compiler emission RFC tied to an accepted runtime owner RFC/ADR | future-gated |
| Migration payloads for active path | denied/future-gated baseline closed by `ISE-MIGRATION-PAYLOAD-AUTHORITY-15`; VMCS projection metadata, compiler artifacts, SecureCompute proof-only, lane/stream evidence, completion projection, and VMREAD output are non-authority | neutral migration descriptor and restore validation | denied until classified |
| Release claim wording | future; conformance matrix closed readiness-only by `ISE-CONFORMANCE-GATES-16`, rollout order closed sequencing-only by `ISE-ROLLOUT-ORDER-GATE-17`, and release gate closed final-claim/readiness-only by `ISE-RELEASE-GATE-18`, so green tests/scans/goldens/PR order/release notes remain non-authority | release gate after exact owner implementation, completion/retire chain, migration/evidence classification, rollback evidence, adjacent denials, and tests | no broad claim |

## 2026-08-07 Compact Status Entry

- E1 provenance: closed evidence-only at clean commit `55807df77978a960382fa913dda4e7ace0093a6b`; local Baseline outcome passed.
- Phase 34 substrate: closed fail-closed only. The D2 schema/validator, commit/reviewer/CODEOWNERS attribution checks, disabled owner interface, opaque unissued E2 type and negative tests exist.
- D2 decision: still blocked. Repository inspection found no CODEOWNERS appointment, attributable neutral-owner acceptance, accepted manifest instance or exact numeric leaf.
- E2 positive admission and E3-E7: blocked/future-gated. Compiler and release gates remain unopened. The new type is not a live certificate and no production caller consumes it.
- Unchanged external state does not create another phase or permission; future monitor results append to this compact entry only when evidence changes.

## 2026-08-08 Compact Status Entry

- Clean D2/E2-substrate evidence: local Baseline passed at `a594d10abcbe8593d23fed16310af30706893452`; this is reproducibility evidence only.
- Validation hardening: malformed SHA, reviewer mismatch, duplicate leaf and incomplete owner map now deny; no test inserts an accepted leaf value.
- Review workflow: prepared but disabled; it cannot create CODEOWNERS attribution, appoint an owner, accept D2 or authorize backend execution.
- D2, E2 positive issuance and E3-E7 remain blocked/future-gated for the same missing attributable governance facts; compiler and release gates remain unopened.

## 2026-08-08 Research Prototype Status Entry

- Phase 36 P1: closed as `TESTING`-only research evidence. A live E1 is revalidated by SafetyVerifier into a prototype operation certificate and a neutral runtime owner produces one no-state/no-payload opaque receipt.
- Revocation and denial: stale E1 before issuance, E1 revocation after prototype admission, foreign owner, stale policy/context and duplicate consumption all deny.
- Non-authority: the receipt is not a numeric leaf decision, production E2/E3 certificate, backend admission, `CompletionRecord`, retire grant or architectural result.
- Production state: Phase 38 now accepts the architecture role and exact ABI, but machine D2 remains blocked; no runtime OwnerId/service or validated accepted v2 instance exists, O1/E2-E7 remain blocked/future-gated, and compiler/release gates remain unopened.
- Phase 37 P2: closed as default-off `TESTING`-only canonical issue/materialization composition. It remains model/testing evidence, not production E2/E3/E4.
- No P3 is authorized. The next safe work is governance/documentation and negative/static hardening of D2 provenance; the next positive production gate remains an attributable accepted D2.

## 2026-08-09 All-Phase Blocker Register

Observation subject: local `HEAD` `ddfffa2d7b86fb3ece21f8d21c6447ae47ee3868` plus the current dirty worktree. The worktree contains Phase 36 P1, Phase 37 P2, diagnostics changes and Phase 38 documentation that are not present in the older clean evidence subjects. The audit-reported public reference `d3814d1f332f083034d3b245f807a45f97792070` is absent from the local object database and its direct origin commit URL returned `404`; containment of local `ddfffa2...` or `a594d10...` in public master is unproven. Local and audit-reported public subjects are not interchangeable. This register is the normative compact status view; files 20-31 remain historical snapshots and their wording about an organizationally external owner is superseded by Phases 33/38. A neutral owner may be repository-local but must be independent from the VMX/VMCS compatibility authority plane and attributable through accepted governance.

| Phase | Current state | Blocking fact | Unlock condition / next permitted work |
| --- | --- | --- | --- |
| 00 index | planning-only | The full production authority chain is incomplete; the corpus cannot approve activation. | Maintain exact-scope claims and active reading order only. |
| 01 state matrix | readiness inventory | No successful canonical VMX execution/writeback path exists; compatibility service projection remains direct/out-of-band. | Re-audit callers after every prototype or production change. |
| 02 static gates | negative gate | A passing scan detects absence but cannot grant authority. | Add fail-closed scans alongside each permitted change. |
| 03 RFC/ADR process | architecture ADR accepted / machine gate open | Phase 38 resolves the role and exact ABI, but no v2 machine artifact, stable OwnerId or attributable review map exists. | Implement only SpecV2/AcceptanceRecordV2 schema, validator and negative attribution gates. |
| 04 VMREAD matrix | projection-only | Architectural VMREAD still lacks D2/E2 owner binding, immutable read effect and retire writeback. | Keep current field-local projections; any new field or ISA path requires its own owner package. |
| 05 GuestCr0/GuestCr4 | closed read-only projection | Any mutation, wider field set, backend, completion, retire or migration meaning is unowned. | Preserve guarded read-only projection; widening starts a new RFC/ADR. |
| 06 hypercall owner RFC | architecture role/ABI accepted; runtime future-gated | `DomainHypercallRuntimeOwner` and exact ABI are decided, but no stable OwnerId, accepted v2 instance, O1, E2 or executor exists. | D2 v2 machine materialization in PR-A/PR-B order; backend remains denied. |
| 07 VMCALL backend | blocked | Production D2, live D2-bound E2 and owner-bound E3 executor/receipt are absent. | No production executor; after D2, implement E2 first, then one exact-leaf E3. |
| 08 completion | future-gated | No live E3 receipt or owner-bound atomic `CompletionRecord + E5` publication seam exists; the current fence consumes booleans and directly constructs a record. | After E4 proof, route E3 through route/fence policy, then let the neutral completion owner atomically publish one record plus E5; only retire owner may consume E5. |
| 09 retire | future-gated | No published E5 completion and no canonical attempt-bound E6 retire grant exist. | Canonical retire owner only, after E5 and precise ordering/squash proofs. |
| 10 VMWRITE | denied | No neutral write owner or command/effect model exists; a mutable VMCS store is forbidden. | Keep denied for the first release; any future write is an owner-specific command, not a field store. |
| 11 nested | future-gated | No authority-issued parent/child identity edge, independent grants, address-space relation or migration contract exists. | Defer; Shadow VMCS remains projection vocabulary only. |
| 12 memory/I/O/IOMMU/lanes | boundary-only | No production attempt-bound virtualized transaction contract exists. Memory/device operations require `VirtualizedTransactionIntent` plus existing MemoryDomain, Io/IOMMU and Device authorizations, lane-local admission where required, attempt-bound opaque tokens and `VirtualizedTransactionReceipt`. | Preserve existing subsystem owners; add no monolithic envelope, new owner or VMX passthrough authority. |
| 13 SecureCompute | denied/boundary | No separately approved secure-runtime relationship proves non-transitive grants and host-evidence isolation. | Keep independent from VMX; secure projection or execution requires its own owner decision. |
| 14 compiler emission | no-emission | No released runtime slice, accepted manifest/hash parity or controlled-emission RFC exists. | Keep default zero emission; the optional Compiler Gate follows runtime E7 and is not runtime authority. |
| 15 migration | future-gated | No active production operation has owner payload, pending-effect ordering, restore invalidation and deterministic resume proof. | P1 receipt remains ephemeral; production E7 follows retire and may start drain-only/NoPayload. |
| 16 conformance | gate-only | Green tests cannot substitute for D2-E7; production positive fixtures are not authority. | Add negatives now; add positives only for a permitted prototype or an owner-approved production phase. |
| 17 rollout | sequencing-only | Architecture D2 choices are decided, but machine D2 is blocked. Research P1/P2 remain TESTING-only and no P3 is authorized. | Next safe pool: D2 v2 governance/negative hardening; next positive production gate is machine-validated D2/O1. |
| 18 release | `NO-GO` | Current dirty worktree lacks a clean containing SHA for P1/P2, and production D2-E7 are incomplete. | Local clean-SHA evidence is required before any release claim; no remote operation is part of this local task. |
| 19 backlog | active journal | Exact first-slice decision is recorded; its machine attribution/runtime stages and all unrelated backlog items remain unresolved. | Maintain this compact register; do not create more wait-only phases. |
| 20 intake packet | historical | Packet preparation was not owner acceptance and allocated no leaf. | No active dependency; consume only a future accepted D2 artifact. |
| 21 handoff | historical | Handoff/absence of response created no authority. | No active dependency; repository-local neutral governance is allowed. |
| 22 fallback | historical | No-response fallback did not select or approve an owner. | No repeated wait phase; record only changed evidence in Phase 19. |
| 23 replacement decision | historical | Continuing to wait was a process result, not a runtime gate. | Superseded as active workflow by D2 governance plus the P1/P2 research lane. |
| 24 late audit | historical | Search completion and silence are non-authority. | Append only materially changed evidence to Phase 19. |
| 25 monitor | historical | Cadence/elapsed time cannot appoint an owner or allocate a leaf. | No new monitor phase. |
| 26 artifact recheck | historical | No attributable accepted artifact was found. | Revalidate only when a concrete D2 artifact appears. |
| 27 wait/reselect | historical | No replacement owner-specific intake was selected. | No active dependency; current production blocker is D2. |
| 28 denied-chain refresh | historical/current fact | Production remains `MissingNeutralOwner -> backend denied -> ProjectionOnlyDenied -> completion/retire denied`. | Preserve until independently authorized production phases replace individual arrows. |
| 29 watchdog | historical | Watchdog result is evidence of no change, not permission. | No new watchdog phase. |
| 30 final wait baseline | historical | Baseline closed only the wait series; it did not close D2. | Use Phase 19 register for current state. |
| 31 sentry | historical | Sentry found no artifact and cannot become an activation trigger. | Re-audit only on a concrete attributable artifact. |
| 32 E1 | `CLOSED/FAULT-ONLY` | E1 intentionally lacks leaf/address-space/capability/evidence/restore and backend/publication authority. | Preserve E1; production E2 consumes D2 and live canonical identities. |
| 33 audit reconciliation | reconciled/historically superseded in part | Phase 38 promotes the previously candidate role/width/leaf/operation into an architecture ADR; P1/P2 still cannot satisfy D2. | Retain audit2 denials and authority separation; use Phase 38 for exact first-slice decisions. |
| 34 D2/E2 substrate | closed fail-closed v1 | No CODEOWNERS mapping, stable OwnerId, accepted v2 instance or production E2 issuer exists; `AcceptedCommitSha` inside the same accepted manifest is not a sufficient final provenance model. | Prepare SpecV2 + separate AcceptanceRecordV2 schema/validator and denial tests only; no populated accepted instance. |
| 35 clean evidence/review workflow | closed evidence-only | Evidence covers `a594d10...`, not the current P1/P2 worktree; disabled review cannot accept D2. | Rebaseline locally only when requested; governance must be attributable and external to compatibility, not necessarily to the repository. |
| 36 research P1 | `CLOSED/TESTING-ONLY` | P1 is a direct research service path, not production E2/E3, completion or retire; no clean containing SHA exists. | Preserved as the no-state/no-payload primitive consumed only by closed P2. |
| 37 research P2 | `CLOSED/TESTING-ONLY` | Default-off canonical issue/materialization composition is model/testing evidence only; no clean containing SHA, numeric leaf or production caller exists. | No P3 is authorized; next production gate is blocked D2. |
| 38 first-slice repository-owner ADR | `ACCEPTED ARCHITECTURE / NO RUNTIME AUTHORITY` | Machine D2, OwnerId/reviewer attribution, O1, operand snapshot and E2-E7 do not exist. Exact capability/evidence/domain/cancellation/replay/completion-evidence/completion-migration values remain unresolved; first-slice SecureCompute behavior is denied. | PR-A v2 governance substrate only; no populated accepted record, backend, completion or retire. |

### Active Critical Blockers

1. **Machine governance D2:** Phase 38 decides the neutral role and exact ABI, but SpecV2/AcceptanceRecordV2, stable non-zero OwnerId, matched review/CODEOWNERS evidence and a validated accepted instance do not exist.
2. **O1 and production E2:** no immutable owner-policy snapshot, canonical full-value operand snapshot or D2-bound SafetyVerifier certificate over capability/evidence/attempt/restore identities exists. Address-space identity must be absent for the exact no-state probe rather than copied from the v1 denied substrate.
3. **Production E3/E4:** no exact-leaf executor/opaque receipt and no proof that the Phase 38 per-attempt chain is the only canonical production composition to E3. Phase 37 P2 is TESTING-only and cannot satisfy either gate.
4. **Publication E5/E6:** no owner-bound atomic completion-record/E5 seam and no canonical retire grant; compatibility DTOs, fence booleans and `VmxRetireEffect` remain insufficient.
5. **E7 evidence:** no active-path migration payload, restore invalidation, rollback drill or FSP/SMT determinism proof.
6. **Release evidence:** the current Phase 36/37 worktree is not bound to a clean containing SHA; older manifests prove only their recorded subjects. This local-only task neither requires nor authorizes remote Git access.
7. **Independent deferred surfaces:** architectural VMREAD, VMWRITE, nested, SecureCompute, memory/IOMMU passthrough and compiler emission each require separate owner decisions and cannot inherit hypercall authority.
8. **Canonical operand identity:** current compatibility qualification contains register selectors, not immutable runtime operand values. Production E2 cannot open until canonical operand materialization binds the full `Rs1` value, `Rs2=x0`, `Rd=x0`, high-bit-zero proof, attempt, VT/domain/context, replay/bundle and restore generation without later register-file re-read.
9. **Non-forgeable publication:** constructible route/fence booleans, `CompletionRecord` factories and positive `VmxRetireEffect` factories are not E3/E5/E6. After E3 and route/fence policy, the neutral completion owner must atomically publish one `CompletionRecord` plus one opaque E5 proof; only the retire owner consumes E5 into the separate canonical E6 grant.

### Adopted Resolution Of Phase 19 Blockers

1. Accept `DomainHypercallRuntimeOwner` as the neutral architecture role for the exact first slice. Do not infer a runtime service instance, stable OwnerId, reviewer identity or live authority from the name.
2. Use immutable `VirtualizationDecisionSpecV2` plus later `VirtualizationDecisionAcceptanceRecordV2` (spec SHA+digest, attributable reviewer/CODEOWNERS evidence and acceptance/withdrawal lineage). The acceptance record never claims the SHA of its own containing commit.
3. Accept only namespace `HybridCPU.VMCALL.Runtime.v1`, 16-bit width, invalid `0x0000`, exact leaf `0x0001`, operation `PROBE_NO_STATE_V1`, `Rs1` full value, `Rs2=x0`, `Rd=x0`, no-state/no-payload/no-result/no-PC-redirect and `DrainOnly`. VMFUNC value 1 is a separate namespace; no truncation is allowed.
4. After machine D2, materialize O1 as immutable owner policy, then actual runtime operand values once at the canonical E1-bound seam into a separate immutable snapshot. E2 consumes both; E3 and later stages cannot reconstruct values from `VmxExitQualification` or re-read registers.
5. Keep `ProjectCompatibilityTrap` projection-only. Future production invocation uses a neutral `InvokeHypercall`-equivalent operation after E2; no compatibility frontend or handler may call the executor.
6. Treat E3 receipt, E5 completion-publication proof and E6 retire grant as three distinct opaque, attempt-bound, consume-once authorities. E5 is emitted atomically with one already-published `CompletionRecord` and only retire consumes it. Existing compatibility DTOs remain data only.
7. Stop the research lane at P2. Use the separate build/readiness and per-attempt graphs in Phase 38: D2/O1 exist before the attempt; E4 proves the only canonical composition to E3 rather than following E3 at runtime. E5/E6/E7 follow execution. Closing schema/tests/readiness never opens the next dependency; Compiler and Release are separate gates.

## What Can Be Implemented

- Backlog maintenance.
- D2 v2 machine-governance preparation implementing the already accepted architecture vocabulary.
- Negative tests that keep backlog items denied.
- D2 v2 Decision Spec/Acceptance Record schema and validator preparation with malformed/digest/reviewer/self-approval/namespace-collision/duplicate-leaf/incomplete-map/withdrawal denial coverage; no populated accepted record, runtime OwnerId, O1, E2 or executor.
- Fail-closed maintenance of the closed P1/P2 research contracts and diagnostics; no new positive research phase is implied.

## What Remains Denied/Future-Gated

Everything in the production backlog beyond the exact Phase 38 architecture decision remains denied until its machine/runtime gate closes. P1 and P2 are closed as TESTING-only evidence; there is no open positive non-production exception or authorized P3.

## Forbidden Shortcuts

- Treating backlog entry as approval.
- Bundling unrelated backlog items into one broad activation PR.
- Moving SecureCompute, nested, lanes, writes, or compiler emission under the VMCALL owner unless explicitly included and tested.

## Required RFC/ADR

Required for every backlog item before implementation.

## Code Anchors

Path-specific anchors from Phases 04-15.

## Documentation Anchors

- `HybridCPU_ISE/docs/ref2/Old/VirtualiztionRefactoringNew/16_external_audit_activation_readiness_addendum.md`
- `Documentation/Virtualization WhiteBook/17_Roadmap_And_Residual_Risk.md`
- This directory.

## Required Tests

- Each backlog item needs a denied-state test until promoted.
- Promotion PR must include positive and negative tests.

## Required Static/Source Scans

Use Phase 16 scans plus path-specific scans from the promoted RFC/ADR.

## Migration/Evidence Classification

Backlog entries without migration/evidence class remain denied. No implicit default migration class may be used for active paths.

## Completion/Retire Implications

Backlog entries cannot publish completion or retire. A promoted item must define both explicitly or remain non-retiring.

## Exit Criteria

- Backlog remains explicit and current.
- No unresolved item is treated as implementation permission.
- Next production work starts with PR-A SpecV2/AcceptanceRecordV2 schema, validator and negative attribution/collision gates; runtime work starts only after machine D2 and O1.

## Dependency On Previous/Next Phase

Depends on all prior phases. No automatic next phase exists.
