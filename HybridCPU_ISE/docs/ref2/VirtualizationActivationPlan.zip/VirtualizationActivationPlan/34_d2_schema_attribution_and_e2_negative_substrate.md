# Phase 34 - D2 Schema, Attribution And E2 Negative Substrate

Status date: 2026-08-07

Status: `CLOSED/FAIL-CLOSED SUBSTRATE ONLY`; D2 remains `BLOCKED`, production D2-bound E2 issuance remains disabled, and VMX production behavior remains fault-only.

The current schema/validator is v1 negative substrate, not the final acceptance contract. The 2026-08-08 audit found a valid provenance concern: `AcceptedCommitSha` is carried by the same manifest whose state may be `Accepted`, so the object cannot non-circularly name the commit that first contains itself. No populated instance or runtime consumer exists, therefore this does not open a runtime vulnerability, but v1 must not be used to close D2.

## 2026-06-11 Audit Contract

- File name: `34_d2_schema_attribution_and_e2_negative_substrate.md`.
- Purpose: record the machine-readable D2 shape, repository attribution gate, disabled neutral-owner interface and opaque unissued E2 substrate.
- Status: v1 schema/validator and negative guards implemented; Phase 38 accepts the architecture role and exact ABI, but no v2 accepted machine decision, runtime OwnerId/service, certificate issuance or runtime activation exists.
- Scope: D2 states, exact-one-leaf structural validation, commit/reviewer/CODEOWNERS attribution, forbidden compatibility self-approval, disabled owner resolution and E2 denial.
- No-goals: no populated v2 acceptance record, runtime OwnerId/reviewer appointment, backend executor, canonical production connection, completion, retire, migration payload or compiler emission.
- Code anchors: `VirtualizationOperationDecisionManifest.cs`, `DisabledNeutralVirtualizationOperationOwner.cs`, `SafetyVerifier.VirtualizationOperationAdmission.cs`, `virtualization-operation-decision-manifest.schema.json`.
- Authority owner: Phase 38 accepts `DomainHypercallRuntimeOwner` as the architecture role; stable runtime OwnerId/reviewer attribution remains unmaterialized. The existing SafetyVerifier owner controls only the negative E2 evaluation boundary and cannot manufacture machine D2.
- Required RFC/ADR: an attributable neutral owner must supply an accepted SHA-bound artifact and the complete field/operation, owner, value source, capability policy, evidence class, migration class, denial reason map.
- Acceptance criteria: all absent/draft/withdrawn/unattributed/self-approved/leaf-less inputs deny; the owner interface has no execution method; no E2 certificate can be constructed or issued; current VMX execution and retire stay fault-only.
- Tests/static scans: `VmxD2DecisionAndE2NegativeSubstrateTests`, plan guards, VMX-refactoring suite, candidate-name/number scans, backend/completion/retire shortcut scans and CODEOWNERS absence check.
- Risks: treating schema or Phase 38 ADR validity as machine D2/runtime authority, treating an `Accepted` enum value as an accepted artifact, inserting an unvalidated registry entry, using CODEOWNERS presence without matched review, or attaching E2 to production.
- Next-gate dependency: PR-A adds only SpecV2/AcceptanceRecordV2 schema, deterministic serialization, validator and attribution/collision negative gates; machine D2 opens only after later attributable validation, while the separate TESTING-only research lane is governed by Phase 36/37.

## Clean E1 Provenance

E1 is contained by clean local commit `55807df77978a960382fa913dda4e7ace0093a6b`, tree `3f356900b4c534e965a69640e88e0c5ecf902b7c`. The local Baseline run at `artifacts/validation/20260807-181740-Baseline/provenance.json` reports the same SHA and `outcome: passed`. The repository-local evidence manifest records that observation. This proves reproducibility of E1 only; it grants no D2 or runtime authority.

## Implemented D2 Boundary

The JSON schema and C# validator define `Absent`, `Draft`, `Accepted` and `Withdrawn`. `Accepted` is vocabulary, not a repository decision. Validation requires all of the following before returning a structurally valid governance result:

- one decision and operation identity;
- a neutral-runtime owner source, matching attributed owner and a matching 40-hex accepted commit SHA;
- a matching CODEOWNERS rule and completed required review;
- no compatibility-frontend self-approval;
- exactly one numeric leaf supplied by the future owner artifact;
- the complete value-source, capability, evidence, migration and denial map.

No populated decision manifest, CODEOWNERS appointment, owner name, operation name or leaf value is included. The validator performs no file I/O and its positive structural result explicitly keeps backend, completion and retire authority false.

### Required v2 Acceptance-Provenance Contract

Before a real D2 can be accepted, replace the single-object acceptance model with two separately versioned artifacts:

- immutable `VirtualizationDecisionSpecV2`: decision/operation identities, owner attribution, the Phase 38 runtime operand ABI including namespace/width/high-bit policy and exact numeric leaf, state/effect class, capability/evidence/migration/completion/retire/denial maps, and a deterministic content digest;
- later `VirtualizationDecisionAcceptanceRecordV2`: referenced spec commit SHA and digest, attributable required-reviewer/CODEOWNERS evidence, acceptance state, and withdrawal/replacement lineage. It must not claim the SHA of its own containing commit. `AcceptanceRecord`, not `Attestation`, is the normative Phase 38 name.

The generated exact-leaf registry may consume only a valid acceptance record whose referenced spec bytes reproduce the recorded digest. Schema validity, `state=Accepted`, a CODEOWNERS file without matched review, a review-workflow result, or the v1 validator result remains governance evidence only and never becomes E2/runtime authority.

Phase 38 accepts the exact architecture vocabulary, but no v2 code or accepted machine instance exists. The current v1 E2 request also requires `AddressSpaceIdentityPresent`; that is intentionally non-promotable for `PROBE_NO_STATE_V1`, whose v2 operation contract has no address-space identity because it has no memory effect.

Phase 38 supplies the repository-owner architecture decision, but this v2 requirement still does not supply a runtime OwnerId/reviewer identity, accepted machine record or execution permission. Frozen compatibility `ushort` fields did not decide the ABI and remain non-authoritative; truncation is forbidden.

## Disabled Owner And E2 Boundary

`INeutralVirtualizationOperationOwner` exposes only `Resolve`; it has no execution method. The only implementation is disabled and always returns a denial. The opaque E2 certificate has only a private constructor, no issuer and no production carrier. `SafetyVerifier.EvaluateVirtualizationOperationAdmission` maps invalid D2 and disabled-owner state to typed denials and always returns a null certificate.

No compatibility frontend, dispatcher, backend admission path, completion route or retire path references the E2 certificate. E1 remains the last canonical virtualization certificate, and it still carries explicit false authority for backend, completion and retire.

## Closed Checks And Remaining Blocker

Closed in this phase: schema syntax, validator denial taxonomy, SHA/attribution/reviewer/CODEOWNERS gates, compatibility self-approval denial, exact-one-leaf rule without a populated value, disabled owner resolution, opaque unissued E2 type and static shortcut guards.

Still blocked: stable non-zero runtime OwnerId, matching owner/architecture reviewer and CODEOWNERS attribution, SpecV2/AcceptanceRecordV2 implementation, accepted spec SHA/digest and complete machine owner map. Closing the Phase 38 architecture ADR or these readiness checks does not satisfy those facts.

Also blocked: the v2 spec/acceptance-record split, cross-artifact digest verification, withdrawal/replacement semantics, and an immutable canonical runtime operand snapshot. Current decode preserves `rs1`/`rs2` selector identities rather than their values.

## Next Permitted Pool

- strengthen schema/validator diagnostics and repository attribution tooling without inventing a runtime OwnerId/reviewer mapping;
- prepare v2 Decision Spec and Acceptance Record schemas/validator with denial-only fixtures for malformed/mismatched spec SHA, digest mismatch, missing or mismatched reviewer evidence, compatibility self-approval, duplicate/absent leaf, incomplete map, invalid withdrawal lineage and unknown schema version;
- continue evidence-manifest and local CI refresh at clean containing SHAs;
- add only further malformed-input and denial diagnostics; accepted namespace/leaf vocabulary may appear only as schema/validator input and cannot create an accepted registry/runtime path;
- keep the Phase 35 repository-owner review workflow disabled until real CODEOWNERS attribution exists.

E2 positive issuance, E3 backend work, production wiring, completion and retire remain forbidden until D2 is actually accepted and independently verified.

The next safe pool may implement only that v2 governance/negative substrate. It may encode the Phase 38 accepted vocabulary in schema/negative fixtures, but must not add a populated accepted record, runtime OwnerId, production operand snapshot, E2 issuer, backend executor, completion token or retire grant.

Phase 36 does not contradict this closure: its differently named prototype certificate and receipt exist only under `TESTING`, consume no accepted manifest or numeric leaf and are unreachable from production VMX execution.
