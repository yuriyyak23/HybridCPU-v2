# Phase 38 - First Production VMCALL Slice Repository-Owner ADR

Status date: 2026-08-09.

Status: `ACCEPTED ARCHITECTURE DECISION / MACHINE D2 NOT MATERIALIZED / PRODUCTION VMX STILL FAULT-ONLY`.

## 2026-06-11 Audit Contract

- File name: `38_first_production_vmcall_slice_repository_owner_adr.md`.
- Purpose: record the repository owner's acceptance of the verified architectural decisions proposed by `HybridCPU-v2 Virtualization Activation 3.md`, including the first exact VMCALL ABI slice, without mistaking documentation for runtime authority.
- Status: architecture/ABI decision accepted; machine-verifiable D2, runtime E2-E7 and release remain blocked or future-gated.
- Scope: D2 v2 artifact split, neutral hypercall role, exact namespace/leaf/operand/result/effect ABI, O1 policy snapshot, operand snapshot, E2-E7 authority separation and first-slice exclusions.
- No-goals: no production source change, no accepted machine artifact, no runtime owner service, no allowed backend, no completion/retire connection, no broad virtualization activation.
- Code anchors: `VmxInstructionPayload.cs`, `VmxExitQualification.cs`, `VmxFunctionLeaf.cs`, `VirtualizationOperationDecisionManifest.cs`, `SafetyVerifier.VirtualizationOperationAdmission.cs`, `HypercallBackendAdmissionPolicy.cs`, `DisabledNeutralVirtualizationOperationOwner.cs`, `DomainRuntimeOperation.cs`, `TrapCompletionRoutePolicy.cs`, `TrapCompletionPublicationFence.cs`, `VmxRetireModel.cs`.
- Authority owner: the accepted architecture role is `DomainHypercallRuntimeOwner`; SafetyVerifier, neutral completion owner, canonical retire owner and checkpoint/restore owner retain their independent authorities. This document does not supply a runtime instance or reviewer identity.
- Required RFC/ADR: this file is the repository-owner architecture/ABI ADR for the exact first slice; machine D2 additionally requires byte-exact `VirtualizationDecisionSpecV2` plus later `VirtualizationDecisionAcceptanceRecordV2`, stable non-zero OwnerId and attributable review mapping with full owner map: field/operation, owner, value source, capability policy, evidence class, migration class, denial reason.
- Acceptance criteria: the accepted values are unambiguous and code-compatible; every runtime stage remains denied until its typed dependency exists, is live and is consumed in order.
- Tests/static scans: plan guard asserts exact namespace/width/leaf/ABI, distinct VMFUNC namespace, selector-not-value warning, v1 substrate non-promotion and absence of production owner/executor/backend/completion/retire shortcuts.
- Risks: treating this ADR as AcceptedVirtualizationDecision, treating compatibility `ushort` or `VmxExitQualification` as value authority, or implementing E3 before D2/O1/operand/E2.
- Next-gate dependency: PR-A only - D2 v2 schema, deterministic serialization, validator, attribution/reviewer policy and negative tests; no accepted machine instance or backend in that pool.

## Decision Source And Verification Verdict

The repository owner explicitly requested that the recommendations in `docs/ref2/1/VRT/HybridCPU-v2 Virtualization Activation 3.md` be accepted as ADR decisions if they withstand current-code and documentation review. They do, with the corrections and non-claims below.

| Proposed decision | Verdict | Verified disposition |
| --- | --- | --- |
| Separate `VirtualizationDecisionSpecV2` and `VirtualizationDecisionAcceptanceRecordV2` | **accepted** | avoids the v1 self-referential acceptance problem; `AcceptanceRecord`, not `Attestation`, is normative terminology |
| Neutral role `DomainHypercallRuntimeOwner` | **accepted as architecture role** | repository-local placement matches the WhiteBook if independent from VMX/VMCS compatibility; stable OwnerId, reviewer mapping and runtime service are not yet materialized |
| namespace `HybridCPU.VMCALL.Runtime.v1`, 16-bit width, invalid `0x0000`, first leaf `0x0001` | **accepted** | `0x0001` is collision-free only inside this exact namespace; VMFUNC already uses numeric 1 in the distinct frozen `VmxFunctionLeaf` namespace |
| operation `PROBE_NO_STATE_V1` | **accepted** | exact no-state/no-payload/no-result semantics only; it grants no adjacent operation |
| `Rs1` value is leaf; `Rs2=x0`; `Rd=x0` | **accepted with mandatory capture rule** | current payload stores register selectors, not values; the actual full `Rs1` value must be read once after E1, upper bits must be zero and silent truncation is denied |
| O1 as immutable owner-policy snapshot | **accepted and supersedes prior O1 naming** | `VirtualizationOperationOwnerSnapshot` is materialized only from an accepted D2; `VirtualizationOperandSnapshot` is a separate unnumbered runtime object |
| E2/E3/E5/E6 opaque, attempt-bound and consume-once | **accepted** | D2/O1/E1 are not runtime capabilities; E3 is not completion; E5 is not retire |
| E4 uses neutral `InvokeHypercall`-equivalent operation | **accepted for future implementation** | current `DomainRuntimeOperationKind` has `InvokeCapability` and projection-only `ProjectCompatibilityTrap`, but no `InvokeHypercall`; the future operation must be new, use `Source=RuntimeService`, set `IsProjectionOnly=false`, and preserve the existing denial of authoritative compatibility-frontend mutation |
| `DrainOnly`, restore invalidation and architectural-trace determinism | **accepted** | live E1/E2/E3/E5/E6 are non-serializable; timing/lane identity is not an architectural equivalence requirement |
| VMREAD/VMWRITE/nested/SecureCompute/memory/IOMMU/device/lane/compiler exclusions | **accepted** | they remain separate owner-specific future gates and do not block the exact no-state probe |

## Accepted Exact ABI Decision

The repository-owner architecture decision is:

```text
OperationNamespace  = HybridCPU.VMCALL.Runtime.v1
LeafWidth           = 16
InvalidLeaf         = 0x0000
NumericLeaf         = 0x0001
OperationId         = PROBE_NO_STATE_V1
OperandAbiVersion   = 1
Rs1                 = architectural register containing the full numeric leaf value
Rs2                 = x0
Rd                  = x0 / no result
ResultAbi           = NoPayload
EffectClass         = NoStateNoPayload
MigrationPolicy     = DrainOnly
```

`0x0001` is accepted only as the leaf in `HybridCPU.VMCALL.Runtime.v1`. It does not alter or alias `VmxFunctionLeaf.CapabilityQuery = 1`, does not reserve value 1 in any other namespace, and does not make the frozen compatibility enum a runtime registry.

The operation has no architectural register write, memory, I/O, DMA/IOMMU, device, SecureCompute, nested, scheduler-visible, explicit PC-redirect or payload effect. Physical placement may retain the existing serializing VMX/SystemSingleton-compatible contour; placement is not authority.

## Mandatory Operand Correction

Current code proves that `VmxInstructionPayload.FromDecodedRegisters` constructs `VmxExitQualification(rs1, ..., rs2)` from encoded register identifiers. Therefore:

- `VmxExitQualification.Leaf` is a compatibility selector projection, not the runtime numeric leaf value;
- the full architectural value of `Rs1` is captured exactly once after the live E1-bound canonical materialization;
- `VirtualizationOperandSnapshot` binds selector, full value, attempt, VT/domain/context, source/working slots, bundle/replay and restore generation;
- `fullRs1Value & ~0xFFFFUL` must equal zero before conversion to `ushort`;
- E2/E3/E5/E6 may not re-read the register file or reconstruct the value from compatibility payload;
- nonzero `Rs2`, nonzero/result-bearing `Rd`, zero leaf, high bits, unknown leaf and adjacent leaf are denied.

The current decoder can represent `x0` as register id zero and VMCALL has no registered writeback opcode. It does not yet enforce this exact ABI shape; that enforcement belongs to the future D2/O1/operand/E2 chain, not to this documentation change.

## Normative D2 And O1 Contract

`VirtualizationDecisionSpecV2` contains the exact operation/owner/ABI/effect/capability/evidence/domain/cancellation/replay/operation-migration/completion-migration/completion/retire/adjacent-leaf policy and a deterministic digest. It cannot mark itself accepted.

`VirtualizationDecisionAcceptanceRecordV2` references the exact `DecisionId`, `SpecDigest` and `SpecCommitSha`, records acceptance state, accepting identity, policy version, owner and architecture review evidence, supersession lineage and its own digest. It must not claim the SHA of its own containing commit.

`VirtualizationDecisionValidatorV2` denies unsupported schema, noncanonical serialization, digest/SHA mismatch, zero or duplicate leaf, namespace collision, incomplete ABI/owner map/policies, missing or mismatched reviewers, compatibility self-approval, revoked or superseded decisions and unknown/adjacent leaves.

`VirtualizationOperationOwnerSnapshot` (O1) is an immutable runtime-loaded policy snapshot derived only from one machine-validated `AcceptedVirtualizationDecision`. It binds DecisionId/digest, OwnerId/policy version, namespace/operation/leaf/ABI/effect and policy classes. O1 is not a runtime capability.

Architecture role acceptance in this ADR does not close machine D2. D2 remains `DECIDED-BUT-NOT-MATERIALIZED / BLOCKED` until all of the following exist together:

- v2 spec, acceptance-record and validator implementation;
- a stable non-zero OwnerId for `DomainHypercallRuntimeOwner`;
- attributable required owner and architecture reviewer mapping/CODEOWNERS policy;
- a byte-exact accepted spec and later acceptance record passing the validator;
- revocation/supersession policy and exact generated runtime lookup inputs.

This phase is the architecture/ABI ADR, not a completed machine D2 policy. The following exact machine values remain unresolved and must be selected and accepted by the named owners rather than inferred from this document: `CapabilityRequirement`, `EvidenceRequirement`, `DomainRequirement`, cancellation semantics, replay semantics, completion evidence class, and `CompletionMigrationClass`. `OperationMigrationPolicy = DrainOnly` is accepted and is a distinct field.

The first slice is explicitly denied in a `SecureCompute` domain. An ordinary VMCALL capability, evidence item, D2 policy or E2 certificate cannot transitively authorize SecureCompute. Any future secure-domain operation restarts at a separate SecureCompute owner decision and authority chain.

## Normative Runtime Authority Chain

The implementation/readiness dependency and the per-attempt runtime chain are different graphs. PR order is not runtime authority, and a readiness node is not consumed as though it were a live certificate.

### Build / Readiness Dependency

```text
VirtualizationDecisionSpecV2
  + VirtualizationDecisionAcceptanceRecordV2
  -> D2 accepted
  -> O1 loaded

E0 reproducible evidence
  + E1 implementation readiness
  -> production composition may be implemented
```

D2 and O1 must exist before a concrete runtime attempt. E0/E1 readiness permits the implementation pool to be considered; it does not authorize an attempt or skip D2/O1.

### Per-Attempt Runtime Chain

```text
canonical decode
  -> generic legality / owner-domain guards
  -> Stage A
  -> Stage B
  -> E1
  -> one-time VirtualizationOperandSnapshot
  -> D2/O1 exact operation resolution
  -> RuntimeBoundaryAdmissionService
  -> neutral TrapRequest / TrapPolicy
  -> NeutralTrapResult
  -> SafetyVerifier E2
  -> DomainHypercallRuntimeExecutor
  -> E3
```

`E4` is the proof/property that the chain above is the only canonical production composition that can reach E3. E4 is not a runtime authority object and is not a stage consumed after E3. PR-F must introduce a new neutral runtime operation such as `InvokeHypercall` or an exact owner-approved equivalent with `Source=RuntimeService` and `IsProjectionOnly=false`; it must not reuse `ProjectCompatibilityTrap`.

For `PROBE_NO_STATE_V1`, AddressSpaceIdentity is absent by contract because the operation has no memory effect. The Phase 34 v1 denied E2 request currently requires `AddressSpaceIdentityPresent`; it is historical fail-closed substrate and must not be promoted. The v2 certificate contract makes identity requirements operation-specific while preserving all domain/capability/evidence/attempt/restore bindings.

Only SafetyVerifier may issue E2 after the existing legality, Stage A, Stage B and E1 chain. `DomainHypercallRuntimeExecutor` may consume one live E2 and return one opaque E3; it may not publish completion or retire.

The future positive completion lifecycle is:

```text
E3
  -> TrapCompletionRouteService
  -> TrapCompletionPublicationFence policy decision
  -> neutral completion owner
  -> atomic publication:
       CompletionRecord
       + opaque E5 CompletionPublicationToken
```

E5 is the non-forgeable proof of exactly one already-published completion. It is emitted atomically with that record, cannot grant its own publication, and may be consumed only by the canonical retire owner. The current `TrapCompletionPublicationFence` accepts caller-provided authorization booleans and directly constructs `CompletionRecord`; that shape is policy/compatibility scaffolding and must be replaced, not promoted, for a positive E5 path. E6 is issued only at canonical retire eligibility and ordering from one live E5. Restore increments generation and invalidates all pre-restore live authority.

`OperationMigrationPolicy` and `CompletionMigrationClass` are separate D2 fields:

```text
OperationMigrationPolicy = DrainOnly
CompletionMigrationClass = <exact owner-approved class; unresolved>
```

The existing fence's `TrapCompletionMigrationClass` classification is not the operation checkpoint policy. For the first slice, checkpoint is allowed only after drain, so no live E5 is migrated or serialized. A future positive completion class must still be selected by its owner and must satisfy the existing retire-fence semantics rather than borrowing `DrainOnly` as a completion class.

Compiler emission and release are governance gates, not authority stages:

```text
Compiler Gate = optional
Release Gate  = exact-scope
```

E2-E7 remain blocked; compiler and release gates remain unopened.

## Public / Local Provenance Boundary

The external audit names `d3814d1f332f083034d3b245f807a45f97792070` as a public GitHub reference. On 2026-08-09 that object was absent from the local object database, and direct resolution of the origin commit URL returned `404`. The local subjects `ddfffa2d7b86fb3ece21f8d21c6447ae47ee3868` and `a594d10abcbe8593d23fed16310af30706893452` do resolve locally, but their containment in any public master is not proven.

Therefore Phase 34-38 code anchors and implementation claims are evidence for this local refactoring branch/worktree only unless independently found in a named public-reference SHA. The audit-reported public reference, local later subjects and dirty worktree must never be substituted for one another in a manifest or release claim.

## Remaining Production Blockers

1. PR-A machine substrate: `VirtualizationDecisionSpecV2`, `VirtualizationDecisionAcceptanceRecordV2`, deterministic serialization, validator, reviewer/CODEOWNERS policy and complete negative matrix.
2. PR-B machine materialization: stable non-zero OwnerId, attributable accepted spec/record and exact generated lookup; backend still denied.
3. PR-C O1 plus canonical `VirtualizationOperandSnapshot`; no positive backend.
4. PR-D production E2, SafetyVerifier-only, exact attempt/leaf/owner/policy/grant/evidence/restore binding.
5. PR-E exact-leaf E3 executor/receipt, default-off and no publication.
6. PR-F canonical E4 through a neutral `InvokeHypercall`-equivalent runtime operation; compatibility direct invocation remains forbidden.
7. PR-G E5 through existing route/fence and neutral completion owner.
8. PR-H E6 through canonical retire.
9. PR-I E7 drain/restore/determinism evidence.
10. PR-J clean containing-SHA evidence, rollback/kill switch and exact-scope limited release review.

## Explicit Non-Authorization

This ADR does not create `AcceptedVirtualizationDecision`, O1, E2, E3, E5, E6 or a completion record; does not add an allowed backend decision, executor, `InvokeHypercall` production operation or frontend/dispatcher connection; does not change fault-only VMX behavior; and does not authorize VMREAD ISA execution, VMWRITE, nested virtualization, SecureCompute, memory/IOMMU/device effects, lane/stream authority, compiler emission or broad activation.

Passing docs, tests, static scans, CI or clean-SHA evidence cannot skip a dependency. Production remains `MissingNeutralOwner`/backend denied/projection-only completion denied/retire denied until each future implementation gate is independently completed.

## Next Open Pool

Only PR-A is open: add the v2 governance schema/validator and negative/static guards. It may encode the accepted exact decision vocabulary but must not add a populated accepted record, non-zero runtime OwnerId, allowed backend admission, executor, positive E2 issuance, production composition, completion or retire path. PR-B opens only after PR-A's machine and attribution contract is complete.
